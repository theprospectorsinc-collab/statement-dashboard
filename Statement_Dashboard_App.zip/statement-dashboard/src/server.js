require('dotenv').config();
const express = require('express');
const session = require('express-session');
const { google } = require('googleapis');
const cron = require('node-cron');
const path = require('path');
const fs = require('fs');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));
app.use(session({
  secret: process.env.SESSION_SECRET || 'change-this-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 7 * 24 * 60 * 60 * 1000 }
}));

// ─── Google OAuth Clients ───────────────────────────────────────────────────
function makeOAuthClient() {
  return new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URI
  );
}

const SCOPES = [
  'https://www.googleapis.com/auth/gmail.readonly',
  'https://www.googleapis.com/auth/drive.file',
  'https://www.googleapis.com/auth/userinfo.email'
];

// ─── Data persistence (file-based, swap for DB on Railway) ─────────────────
const DATA_FILE = path.join(__dirname, '../data.json');
function loadData() {
  if (fs.existsSync(DATA_FILE)) return JSON.parse(fs.readFileSync(DATA_FILE));
  return { tokens: {}, completions: {}, accounts: null };
}
function saveData(data) {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

// ─── Auth Routes ────────────────────────────────────────────────────────────
// Connect Gmail account (1 or 2)
app.get('/auth/google/:slot', (req, res) => {
  const slot = req.params.slot; // '1' or '2'
  const oauth2Client = makeOAuthClient();
  const url = oauth2Client.generateAuthUrl({
    access_type: 'offline',
    prompt: 'consent',
    scope: SCOPES,
    state: slot
  });
  res.redirect(url);
});

app.get('/auth/callback', async (req, res) => {
  const { code, state: slot } = req.query;
  const oauth2Client = makeOAuthClient();
  const { tokens } = await oauth2Client.getToken(code);
  oauth2Client.setCredentials(tokens);

  // Get email address to confirm which account
  const oauth2 = google.oauth2({ version: 'v2', auth: oauth2Client });
  const { data } = await oauth2.userinfo.get();

  const appData = loadData();
  appData.tokens[`gmail${slot}`] = tokens;
  appData.tokens[`gmail${slot}_email`] = data.email;
  saveData(appData);

  res.redirect(`/?connected=gmail${slot}&email=${encodeURIComponent(data.email)}`);
});

app.get('/auth/status', (req, res) => {
  const data = loadData();
  res.json({
    gmail1: data.tokens.gmail1 ? { connected: true, email: data.tokens.gmail1_email } : { connected: false },
    gmail2: data.tokens.gmail2 ? { connected: true, email: data.tokens.gmail2_email } : { connected: false }
  });
});

// ─── Drive: Ensure monthly folder exists ────────────────────────────────────
async function getOrCreateFolder(drive, name, parentId = null) {
  const q = parentId
    ? `name='${name}' and mimeType='application/vnd.google-apps.folder' and '${parentId}' in parents and trashed=false`
    : `name='${name}' and mimeType='application/vnd.google-apps.folder' and trashed=false`;

  const { data } = await drive.files.list({ q, fields: 'files(id,name)', spaces: 'drive' });
  if (data.files.length > 0) return data.files[0].id;

  const { data: folder } = await drive.files.create({
    requestBody: {
      name,
      mimeType: 'application/vnd.google-apps.folder',
      ...(parentId ? { parents: [parentId] } : {})
    },
    fields: 'id'
  });
  return folder.id;
}

async function getMonthlyFolderId(drive, year, month) {
  const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  const folderName = `${year}-${String(month+1).padStart(2,'0')} ${MONTHS[month]}`;
  const rootId = await getOrCreateFolder(drive, 'Monthly Statements');
  return getOrCreateFolder(drive, folderName, rootId);
}

// ─── Drive: Upload file ──────────────────────────────────────────────────────
app.post('/api/upload', express.raw({ type: '*/*', limit: '50mb' }), async (req, res) => {
  try {
    const { filename, year, month, mimeType } = req.query;
    const data = loadData();
    if (!data.tokens.gmail1) return res.status(401).json({ error: 'Google Drive not connected' });

    const oauth2Client = makeOAuthClient();
    oauth2Client.setCredentials(data.tokens.gmail1);
    const drive = google.drive({ version: 'v3', auth: oauth2Client });

    const folderId = await getMonthlyFolderId(drive, parseInt(year), parseInt(month));

    const { data: file } = await drive.files.create({
      requestBody: { name: filename, parents: [folderId] },
      media: { mimeType: mimeType || 'application/pdf', body: require('stream').Readable.from(req.body) },
      fields: 'id,name,webViewLink'
    });

    res.json({ success: true, fileId: file.id, fileName: file.name, url: file.webViewLink });
  } catch (err) {
    console.error('Upload error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ─── Gmail: Scan for statement emails ───────────────────────────────────────
async function scanGmail(slot, rules) {
  const data = loadData();
  const tokens = data.tokens[`gmail${slot}`];
  if (!tokens) return [];

  const oauth2Client = makeOAuthClient();
  oauth2Client.setCredentials(tokens);
  const gmail = google.gmail({ version: 'v1', auth: oauth2Client });
  const results = [];

  for (const rule of rules) {
    try {
      const query = `from:${rule.sender} newer_than:35d`;
      const { data: list } = await gmail.users.messages.list({ userId: 'me', q: query, maxResults: 10 });
      if (!list.messages) continue;

      for (const msg of list.messages) {
        const { data: full } = await gmail.users.messages.get({ userId: 'me', id: msg.id, format: 'full' });
        const headers = full.payload.headers;
        const subject = headers.find(h => h.name === 'Subject')?.value || '';
        const date = headers.find(h => h.name === 'Date')?.value || '';

        // Check for attachments
        const parts = full.payload.parts || [];
        const attachments = parts.filter(p => p.filename && p.body?.attachmentId);

        // Check for links in body
        let bodyLink = null;
        const bodyPart = parts.find(p => p.mimeType === 'text/html') || parts.find(p => p.mimeType === 'text/plain');
        if (bodyPart?.body?.data && attachments.length === 0) {
          const bodyText = Buffer.from(bodyPart.body.data, 'base64').toString();
          const linkMatch = bodyText.match(/https?:\/\/[^\s"'<>]+/);
          if (linkMatch) bodyLink = linkMatch[0];
        }

        results.push({
          accountId: rule.accountId,
          messageId: msg.id,
          subject,
          date,
          hasAttachment: attachments.length > 0,
          attachments: attachments.map(a => ({ name: a.filename, attachmentId: a.body.attachmentId, size: a.body.size })),
          bodyLink,
          sender: rule.sender
        });
      }
    } catch (err) {
      console.error(`Gmail scan error for ${rule.sender}:`, err.message);
    }
  }
  return results;
}

// Rules for which emails to watch
const EMAIL_RULES = [
  // Full auto (attachments) — Gmail #1
  { slot: 1, accountId: 26, sender: 'system@sent-via.netsuite.com', keyword: 'invoice' },
  { slot: 2, accountId: 28, sender: 'atm@provider.com', keyword: 'balance' },
  // Semi-auto (links) — Gmail #1
  { slot: 1, accountId: 25, sender: 'notifier@nayax.com', keyword: 'statement' },
  // Add your bank/card/insurance senders here:
  // { slot: 1, accountId: 1, sender: 'statements@usbank.com', keyword: 'statement' },
];

app.get('/api/scan', async (req, res) => {
  try {
    const slot1Rules = EMAIL_RULES.filter(r => r.slot === 1);
    const slot2Rules = EMAIL_RULES.filter(r => r.slot === 2);
    const [results1, results2] = await Promise.all([
      scanGmail(1, slot1Rules),
      scanGmail(2, slot2Rules)
    ]);
    res.json({ results: [...results1, ...results2] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Download attachment from Gmail and upload to Drive
app.post('/api/auto-file', async (req, res) => {
  try {
    const { messageId, attachmentId, filename, accountId, year, month, gmailSlot } = req.body;
    const data = loadData();
    const tokens = data.tokens[`gmail${gmailSlot}`];
    if (!tokens) return res.status(401).json({ error: 'Gmail not connected' });

    const oauth2Client = makeOAuthClient();
    oauth2Client.setCredentials(tokens);
    const gmail = google.gmail({ version: 'v1', auth: oauth2Client });
    const drive = google.drive({ version: 'v3', auth: oauth2Client });

    // Download attachment
    const { data: attachment } = await gmail.users.messages.attachments.get({
      userId: 'me', messageId, id: attachmentId
    });
    const fileBuffer = Buffer.from(attachment.data, 'base64');

    // Upload to Drive
    const folderId = await getMonthlyFolderId(drive, parseInt(year), parseInt(month));
    const { data: file } = await drive.files.create({
      requestBody: { name: filename, parents: [folderId] },
      media: { mimeType: 'application/pdf', body: require('stream').Readable.from(fileBuffer) },
      fields: 'id,name,webViewLink'
    });

    // Mark as complete
    const key = `${year}-${String(month).padStart(2,'0')}_${accountId}`;
    data.completions[key] = { fileName: filename, folder: `Monthly Statements`, uploadedAt: new Date().toISOString(), auto: true };
    saveData(data);

    res.json({ success: true, fileId: file.id, fileName: file.name, url: file.webViewLink });
  } catch (err) {
    console.error('Auto-file error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ─── Completions API ─────────────────────────────────────────────────────────
app.get('/api/completions', (req, res) => {
  const data = loadData();
  res.json(data.completions || {});
});

app.post('/api/completions', (req, res) => {
  const data = loadData();
  data.completions = req.body;
  saveData(data);
  res.json({ success: true });
});

// ─── Accounts API ────────────────────────────────────────────────────────────
app.get('/api/accounts', (req, res) => {
  const data = loadData();
  res.json(data.accounts || null);
});

app.post('/api/accounts', (req, res) => {
  const data = loadData();
  data.accounts = req.body;
  saveData(data);
  res.json({ success: true });
});

// ─── Auto-scan cron: runs daily at 8am ──────────────────────────────────────
cron.schedule('0 8 * * *', async () => {
  console.log('Running daily Gmail scan...');
  try {
    const slot1Rules = EMAIL_RULES.filter(r => r.slot === 1);
    const slot2Rules = EMAIL_RULES.filter(r => r.slot === 2);
    const [r1, r2] = await Promise.all([scanGmail(1, slot1Rules), scanGmail(2, slot2Rules)]);
    const allResults = [...r1, ...r2];
    console.log(`Scan complete: ${allResults.length} emails found`);
    // Auto-file attachments
    for (const result of allResults) {
      if (result.hasAttachment) {
        const now = new Date();
        for (const att of result.attachments) {
          console.log(`Auto-filing: ${att.name} for account ${result.accountId}`);
        }
      }
    }
  } catch (err) {
    console.error('Cron scan error:', err);
  }
});

// ─── Start ───────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Statement dashboard running on port ${PORT}`));
